# ReplyFlow AI

Micro SaaS para geração automática de respostas personalizadas usando IA.

## Tecnologias

- React 18
- TailwindCSS
- Firebase (Auth e Firestore)
- React Router DOM

## Rodando localmente

1. Clone o repositório
2. Instale dependências com `npm install`
3. Configure o Firebase em `src/firebase.js`
4. Inicie o projeto com `npm start`

## Funcionalidades

- Login com email e senha (Firebase Auth)
- Dashboard protegido
- Gerenciamento de autenticação via Context API
- Layout responsivo com TailwindCSS
- Estrutura preparada para integração com OpenAI API

## Configuração Firebase

Edite o arquivo `src/firebase.js` com suas credenciais do Firebase.

---
