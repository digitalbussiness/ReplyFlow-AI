import React from "react";
import { auth } from "../firebase";
import { useNavigate } from "react-router-dom";

export default function Dashboard() {
  const navigate = useNavigate();

  const sair = () => {
    auth.signOut();
    navigate("/login");
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
      <p>Bem-vindo! Aqui você poderá gerar respostas com IA.</p>
      <button onClick={sair} className="mt-4 bg-red-500 text-white px-4 py-2 rounded">
        Sair
      </button>
    </div>
  );
}
